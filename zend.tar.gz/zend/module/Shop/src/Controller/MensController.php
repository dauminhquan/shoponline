<?php
/**
 * Created by PhpStorm.
 * User: quan
 * Date: 29/08/2017
 * Time: 08:24
 */

namespace Shop\Controller;


use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

class MensController extends AbstractActionController
{
    public function indexAction()
    {
        return new ViewModel();
    }
    public function singleAction()
    {
        return new ViewModel();
    }
}