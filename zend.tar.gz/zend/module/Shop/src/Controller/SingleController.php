<?php
/**
 * Created by PhpStorm.
 * User: quan
 * Date: 29/08/2017
 * Time: 21:01
 */

namespace Shop\Controller;


use Admin\Model\DataTable;
use Zend\Mvc\Controller\AbstractActionController;

class SingleController extends AbstractActionController
{
    private $table;
    public function __construct(DataTable $table)
    {
        $this->table = $table;
    }

    public function indexController()
    {
        return new ViewModel();
    }

}