<?php

/**
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2016 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Admin\Controller;

use Admin\Model\DataTable;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Zend\View\Model\ViewModel;
use Admin\Model\BangNguoiDung;
use Admin\Model\User;
class UserTableController extends AbstractActionController {

    private $bangnguoidung;
    public function __construct(DataTable $bangnguoidung) {
        $this->bangnguoidung = $bangnguoidung;
    }
    public function indexAction() {
        $result = $this->bangnguoidung->TakeAll();
        $data = array();
        foreach ($result as $row) {
            if($row['id'] != $_SESSION['id'])
            {
                array_push($data, $row);
            }
            
        }

        return new ViewModel(array(
            'table' => $data,
        ));
    }
    public function addAction()
    {


        if(!isset($_POST['ho']) || !isset($_POST['ten']) || !isset($_POST['ngaythangnamsinh']) || !isset($_POST['sodienthoai'])
            || !isset($_POST['email']) || !isset($_POST['diachi']) ||!isset($_POST['taikhoan']) ||
            !isset($_POST['matkhau']))
        {
            return new ViewModel();
        }
        else{
            try{
                $user = new User();

                $user->Copydata($_POST);
                $dt = $this->bangnguoidung->getTable()->select(array('taikhoan' => $user->taikhoan));
                global $check;
                foreach ($dt as $item)
                {
                    $check = $item;
                    break;
                }
                if(isset($check))
                {
                    return new JsonModel(
                        array(
                            'result' => false,
                            'mss' => 'taikhoan'
                        )

                    );
                }
                $this->bangnguoidung->Save($user);
                return new JsonModel(
                    array(
                        'result' => true,
                        'mss' => $_POST
                    )

                );
            }catch (\Exception $e)
            {
                return new JsonModel(
                    array(
                        'result' => $e->getMessage()
                    )

                );
            }
        }

    }
    public function profileAction()
    {
        $id = $this->params('id');
        if(!isset($id))
        {
            $this->redirect()->toRoute('admin/usertable');
        }
        $result = $this->bangnguoidung->TakeID($id);
        if(!isset($result))
        {
            $this->redirect()->toRoute('admin/usertable');
        }
        return new ViewModel(array(
            'result' => $result
        ));
    }

    public function editAction() {

        if(!isset($_POST['ho']) || !isset($_POST['ten']) || !isset($_POST['ngaythangnamsinh']) || !isset($_POST['sodienthoai'])
        || !isset($_POST['email']) || !isset($_POST['diachi']) ||!isset($_POST['taikhoan']) ||
            !isset($_POST['matkhau']))
        {
            return new JsonModel(array(
                'result' => $_POST
            ));
        }
            else{
                try{
                    $user = new User();
                    $user->Copydata($this->getRequest()->getPost());
                    $this->bangnguoidung->Save($user);
                    return new JsonModel(
                        array(
                            'result' => true,
                            'mss' => $user
                        )

                    );
                }catch (\Exception $e)
                {
                    return new JsonModel(
                        array(
                            'result' => $e->getMessage()
                        )

                    );
                }
            }
    }
    public function deleteAction()
    {
        if (isset($_POST['value'])) {

            foreach ($_POST['value'] as $id)
            {
                $this->bangnguoidung->Delete($id);
            }
            return new JsonModel(array('result' => true));
            
        }
        header('Local '.$this->redirect()->toRoute('admin/usertable'));
    }
    public function upimageAction()
    {
        if(isset($_POST['url']) && isset($_POST['id_user']))
        {
            try{
                $this->bangnguoidung->getTable()->update(array('anhdaidien' => $_POST['url']),['id' => $_POST['id_user']]);
                return new JsonModel(array('result' => true));
            }catch (\Exception $e){
                return new JsonModel(array('result' => $e->getMessage()));
            }

        }
    }
}
