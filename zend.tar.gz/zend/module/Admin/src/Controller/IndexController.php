<?php
namespace Admin\Controller;

use Admin\Model\ModelScript;
use Zend\Db\Adapter\Adapter;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Zend\View\Model\ViewModel;
use Admin\Model\BangNguoiDung;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Adapter\AdapterInterface;
class IndexController extends AbstractActionController {
    private $adapter;
    public function __construct(AdapterInterface $adapter) {
        $this->adapter = $adapter;
    }

    public function indexAction() {
        if(isset($_POST['pic']))
        {
            if($_POST['pic'] == 'revenue')// thống kê doanh thu
            {
                // thời điểm hiện tại
                // hóa đơn từng ngày
                // tổng tiền hóa đơn
                // tính tổng tất cả tiền của các hóa đơn
                $d = date('d');
                $m = date('m');
                $y = date('Y');
                $result = [];
                for($i = 0;$i<6;$i++)
                {
                    $tomorrow  = mktime(0, 0, 0, $m  , $d-$i, $y);
                    $date = date('Y-m-d',$tomorrow);
                    $M = date('m',$tomorrow);
                    $Y = date('Y',$tomorrow);
                    $D = date('d',$tomorrow);
                    $select = $this->adapter->query('SELECT SUM(tongtien) as tongtien FROM (
SELECT id FROM donhang WHERE ngaydatdonhang = "'.$date.'") as B1 INNER JOIN donhang_sanpham ON
B1.id = donhang_sanpham.id_donhang')->execute()->current();
                    array_push($result,['Y' => $Y,'M' => $M,'D' => $D , 'value' => $select]);
                }
                return new JsonModel(array(
                   'result' => $result
                ));
            }
            if($_POST['pic'] == 'invoice')
            {
                $d = date('d');
                $m = date('m');
                $y = date('Y');
                $result = [];
                for($i = 0;$i<6;$i++)
                {
                    $tomorrow  = mktime(0, 0, 0, $m  , $d-$i, $y);
                    $date = date('Y-m-d',$tomorrow);
                    $M = date('m',$tomorrow);
                    $Y = date('Y',$tomorrow);
                    $D = date('d',$tomorrow);
                    $select = $this->adapter->query('
                    SELECT COUNT(id) as count FROM
                     donhang WHERE
                      ngaydatdonhang = "'.$date.'"')->execute()->current();
                    array_push($result,['Y' => $Y,'M' => $M,'D' => $D , 'value' => (int)$select['count']]);
                }
                return new JsonModel(array(
                    'result' => $result
                ));
            }
        }
        //top 5 sản phẩm bán chạy nhất
        $d = date('d');
        $m = date('m');
        $y = date('Y');
        $tomorrow  = mktime(0, 0, 0, $m  , $d - 7, $y);
        $date = date('Y-m-d',$tomorrow);

        $data = $this->adapter->query('
        
        SELECT tensanpham, SUM(B1.soluong) as tongso FROM sanpham
INNER JOIN 
(SELECT donhang_sanpham.id_sanpham,donhang_sanpham.soluong FROM donhang_sanpham INNER JOIN
donhang ON donhang_sanpham.id_donhang = donhang.id
WHERE donhang.ngaydatdonhang > "'.$date.'") as B1
ON
sanpham.id = B1.id_sanpham
GROUP BY sanpham.id
ORDER BY tongso DESC
LIMIT 5
        
        ')->execute();
        $sothanhvien = $this->adapter->query('SELECT COUNT(id) as len FROM nguoidung')->execute()->current();

        $sodonhangdangdoi = $this->adapter->query('SELECT COUNT(id) as len FROM donhang WHERE tinhtrang = 1')->execute()->current();

        $sosanpham = $this->adapter->query('SELECT COUNT(id) as len FROM sanpham')->execute()->current();
        return new ViewModel(
            array(
                'top5' => $data,
                'sothanhvien' => (int)$sothanhvien['len'],
                'dondangdoi' => $sodonhangdangdoi['len'],
                'soluongsanpham' => $sosanpham['len']
            )
        );
    }
}
