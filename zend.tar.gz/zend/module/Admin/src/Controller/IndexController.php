<?php
namespace Admin\Controller;

use Admin\Model\ModelScript;
use Zend\Db\Adapter\Adapter;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Admin\Model\BangNguoiDung;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Adapter\AdapterInterface;
class IndexController extends AbstractActionController {
    private $adapter;
    public function __construct(AdapterInterface $adapter) {
        $this->adapter = $adapter;
    }

    public function indexAction() {

        return new ViewModel(
                array(

                )
                );
    }
}
