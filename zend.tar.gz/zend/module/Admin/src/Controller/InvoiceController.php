<?php

namespace Admin\Controller;

use Admin\Model\DataTable;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

class InvoiceController extends AbstractActionController {

    private $table;
    public function __construct(DataTable $table) {
        $this->table = $table;
    }

    function indexAction() {
        $data = $this->table->TakeAll();
        return new ViewModel();
    }

}
