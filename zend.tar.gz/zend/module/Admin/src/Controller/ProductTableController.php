<?php
namespace Admin\Controller;

use Admin\Model\DataTable;
use Admin\Model\Product;
use Zend\Json\Json;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Zend\View\Model\ViewModel;
class ProductTableController extends AbstractActionController {
    private $bangsanpham;
    private $bangnhomsanpham;
    private $bangloaisanpham;
    private $imagetable;
    public $data;
    public function __construct(DataTable $bangsanpham,DataTable $bangnhomsanpham,
                                DataTable $bangloaisanpham
    , DataTable $imagetable
    ) {
        $this->bangsanpham = $bangsanpham;
        $this->bangnhomsanpham = $bangnhomsanpham;
        $this->bangloaisanpham = $bangloaisanpham;
        $this->imagetable = $imagetable;
    }
    public function indexAction() {
        $id = $this->params('id');
        if(isset($id))
        {
            header('Local '.$this->redirect()->toRoute('admin/producttable',['action' => 'index']));
        }
        $this->data = array();
        $result = $this->bangsanpham->TakeAll();
        foreach ($result as $row)
        {
            $sp = new Product();
            $sp->Copydata($row);
            $dt = $sp->getarray();
            // lay duoc san pham

            //lay bang nhom san pham
            $nsp=$this->bangnhomsanpham->TakeID($row->id_nhomsanpham);
            //lay ten bang nhom sanpham

            $tenbangnhomsanpham = $nsp->tennhomsanpham;
            //lay id_loaisanpham
            $lsp = $this->bangloaisanpham->TakeID($nsp->id_loaisanpham);
            //lay ten loai san pham
            $tenloaisanpham = $lsp->tenloaisanpham;

            $dt['id_loaisanpham'] = $nsp->id_loaisanpham;
            //
            $dt['tenloaisanpham'] = $tenloaisanpham;
            //lay ten loai san pham

            $dt['tennhomsanpham'] = $nsp->tennhomsanpham;
            $dt['thongtinnhomsanpham'] = $nsp->thongtinnhomsanpham;

            $image = $this->imagetable->SQL("SELECT url FROM image WHERE anhdaidien = 1");
            $dt['url'] = $image->current()['url'];
            array_push($this->data,$dt);
        }
        return new ViewModel(array(
            'data' => $this->data,
        ));
    }
    public function deleteAction()
    {
        if($this->getRequest()->isPost() == true)
        {
            if(isset($_POST['value']))
            {
                $data = $_POST['value'];

                for($i=0;$i<count($data);$i++)
                {
                    try{
                        $this->imagetable->SQL("UPDATE image SET id_sanpham = null,anhdaidien = 0 WHERE id_sanpham = ".(int)$data[$i]);
                        $this->bangsanpham->Delete((int)$data[$i]);
                    }catch (\Exception $ex)
                    {
                        return new JsonModel(array(
                            'result' => $ex->getMessage(),
                        ));
                    }
                }
                return new JsonModel(array(
                    'result' => true
                ));
            }
        }
        header('Local '.$this->redirect()->toRoute('admin/producttable',['action'=>'index']));

    }
    public function addAction()
    {
        $xuatxurs = $this->bangsanpham->SQL('SELECT DISTINCT xuatxu FROM sanpham');
        $kichcors = $this->bangsanpham->SQL('SELECT DISTINCT kichco FROM sanpham');
        $maxid = $this->bangsanpham->SQL('SELECT MAX(id) as max_id FROM sanpham')->current()['max_id'];
        $images = $this->imagetable->SQL('SELECT id as id_image,url FROM image WHERE id_sanpham IS null');
        $xuatxu = array();
        foreach ($xuatxurs as $row)
        {
            array_push($xuatxu,array(
               'xuatxu' => $row['xuatxu']
            ));
        }
        $kichco = array();
        foreach ($kichcors as $row)
        {
            array_push($kichco,array(

               'kichco' => $row['kichco']
            ));
        }
        $loaisanpham = $this->bangloaisanpham->SQL('SELECT DISTINCT id,tenloaisanpham FROM loaisanpham');
        $nhom_loaisanpham = array();
        foreach ($loaisanpham as $row)
        {
            $id_loaisanpham = $row['id'];
            $name = $row['tenloaisanpham'];

            $nhomsanpham = $this->bangnhomsanpham->SQL('SELECT DISTINCT id,tennhomsanpham FROM nhomsanpham WHERE id = '.(int) $id_loaisanpham);
            $listnhomsanpham = array();
            foreach ($nhomsanpham as $nrow)
            {
                array_push($listnhomsanpham,array(
                    'id_nhomsanpham' => $nrow['id'],
                    'tennhomsanpham' => $nrow['tennhomsanpham']
                ));
            }
            array_push($nhom_loaisanpham,array(
               'tenloaisanpham' => $name,
                'listnhomsanpham' => $listnhomsanpham
            ));
        }

        return new ViewModel(array(
            'xuatxu' => $xuatxu,
            'kichco' => $kichco,
            'nhomloai_sanpham' => $nhom_loaisanpham,
                'maxid' => $maxid,
                'images' => $images
            )
        );

    }
    public function pushAction()
    {

        if(!isset($_POST['name']) || !isset($_POST['size']) ||!isset($_POST['made']))
        {
            header('Local '.$this->redirect()->toRoute('admin/producttable'));
        }
        try {
            $product = new Product();
            $product->id = $_POST['id'];
            $product->tensanpham = $_POST['name'];
            $product->id_nhomsanpham = 1;
            $product->gioitinh = $_POST['sex'];
            $product->xuatxu = $_POST['made'];
            $product->kichco = $_POST['size'];
            $product->thongtinsanpham = $_POST['infor'];
            $product->soluong = $_POST['_number'];
            $product->ngaythemvao = date('Y/m/d');
            $product->cannang = $_POST['weight'];
            $product->gia = (int)$_POST['price'];
            $id_ = (!empty($_POST['id_'])) ? $_POST['id_'] : null;
            $new_images = (!empty($_POST['new_img_select'])) ? $_POST['new_img_select'] : null;
            $check_id_img = (!empty($_POST['check_img'])) ? $_POST['check_img'] : null;
            $un_check_id_img = (!empty($_POST['un_check_img'])) ? $_POST['un_check_img'] : null;
            $_id = (!empty($_POST['_id'])) ? $_POST['_id'] : null;
        }
        catch (\Exception $e)
        {
            return new JsonModel(array(
               'result' => $e->getMessage()
            ));
        }
        try{
             $dt = $this->bangsanpham->Save($product);
             // them moi san pham
             if(isset($new_images) && isset($id_) && $id_ !=0)
             {
                 for ($i = 0; $i<count($new_images);$i++)
                 {
                     $this->imagetable->getTable()->insert(array('url'=> $new_images[$i],'id_sanpham' => $id_));
                 }

             }

            if(isset($new_images) && isset($_id) && $_id !=0)
            {
                for ($i = 0; $i<count($new_images);$i++)
                {
                    $this->imagetable->getTable()->insert(array('url'=> $new_images[$i],'id_sanpham' => $_id));
                }

            }

            if(isset($un_check_id_img) && isset($_id))
            {
                for ($i = 0; $i<count($un_check_id_img);$i++)
                {
                    $this->imagetable->getTable()->update(array('id_sanpham'=> null),["id" => $un_check_id_img[$i]]);
                }
            }

             if(isset($check_id_img) && isset($id_))
             {
                 for ($i = 0; $i<count($check_id_img);$i++)
                 {
                     $this->imagetable->getTable()->update(array('id_sanpham'=> $id_),["id" => $check_id_img[$i]]);
                 }
             }
             //update
            if(isset($check_id_img) && isset($_id))
            {
                for ($i = 0; $i<count($check_id_img);$i++)
                {
                    $this->imagetable->getTable()->update(array('id_sanpham'=> $_id),["id" => $check_id_img[$i]]);
                }
            }
             // update san pham
            ///
            /// //
            return new JsonModel(array(
                'result' => true,
                'data' => $dt
            ));
        }
        catch (\Exception $e)
        {
            return new JsonModel(array(
               'result' => $e->getMessage()
//              'result' => false
            ));
        }


    }
    public function profileAction()
    {
        $id_product = $this->params('id');
        if($id_product==0)
        {
            header('Local '.$this->redirect()->toRoute('admin/producttable',['action' => 'add']));
        }

        $result = $this->bangsanpham->TakeID($id_product);
        if(!isset($result))
        {
            header('Local '.$this->redirect()->toRoute('admin/producttable'));
            return;
        }
        $xuatxurs = $this->bangsanpham->SQL('SELECT DISTINCT xuatxu FROM sanpham');
        $kichcors = $this->bangsanpham->SQL('SELECT DISTINCT kichco FROM sanpham');
        $xuatxu = array();
        foreach ($xuatxurs as $row)
        {
            array_push($xuatxu,array(
                'xuatxu' => $row['xuatxu']
            ));
        }
        $kichco = array();
        foreach ($kichcors as $row)
        {
            array_push($kichco,array(

                'kichco' => $row['kichco']
            ));
        }
        $loaisanpham = $this->bangloaisanpham->SQL('SELECT DISTINCT id,tenloaisanpham FROM loaisanpham');
        $nhom_loaisanpham = array();
        foreach ($loaisanpham as $row)
        {
            $id_loaisanpham = $row['id'];
            $name = $row['tenloaisanpham'];

            $nhomsanpham = $this->bangnhomsanpham->SQL('SELECT DISTINCT id,tennhomsanpham FROM nhomsanpham WHERE id = '.(int) $id_loaisanpham);
            $listnhomsanpham = array();
            foreach ($nhomsanpham as $nrow)
            {
                array_push($listnhomsanpham,array(
                    'id_nhomsanpham' => $nrow['id'],
                    'tennhomsanpham' => $nrow['tennhomsanpham']
                ));
            }
            array_push($nhom_loaisanpham,array(
                'tenloaisanpham' => $name,
                'listnhomsanpham' => $listnhomsanpham
            ));
        }

        $images_free = $this->imagetable->SQL('SELECT id as id_img,url FROM image WHERE id_sanpham IS null OR id_sanpham = 0');
        $images = $this->imagetable->getTable()->select(['id_sanpham' => $result['id']]);
        return new ViewModel(array(

                'xuatxu' => $xuatxu,
                'kichco' => $kichco,
                'nhomloai_sanpham' => $nhom_loaisanpham,
                'name' => $result['tensanpham'],
                'made'=> $result['xuatxu'],
            'id' => $result['id'],
            'size' => $result['kichco'],
            'sex' => $result['gioitinh'],
            'group' => $result['id_nhomsanpham'],
            'price' => $result['gia'],
            'number' => $result['soluong'],
            'weight' => $result['cannang'],
            'infor' => $result['thongtinsanpham'],
            'images' => $images,
            'images_free' => $images_free
        ));

    }
}
