<?php

namespace Admin\Model;

class Product {

    public $id, $tensanpham,$gia, $id_nhomsanpham,$gioitinh,$xuatxu,$kichco,$thongtinsanpham,$soluong,$ngaythemvao,$cannang;

    public function Copydata($data) {
        $this->id = (!empty($data['id'])) ? $data['id'] : null;
        $this->tensanpham = (!empty($data['tensanpham'])) ? $data['tensanpham'] : null;
        $this->id_nhomsanpham = (!empty($data['id_nhomsanpham'])) ? $data['id_nhomsanpham'] : null;
        $this->gioitinh = (!empty($data['gioitinh'])) ? $data['gioitinh'] : null;
        $this->xuatxu = (!empty($data['xuatxu'])) ? $data['xuatxu'] : null;
        $this->kichco = (!empty($data['kichco'])) ? $data['kichco'] : null;
        $this->thongtinsanpham = (!empty($data['thongtinsanpham'])) ? $data['thongtinsanpham'] : null;
        $this->soluong = (!empty($data['soluong'])) ? $data['soluong'] : null;
        $this->ngaythemvao = (!empty($data['ngaythemvao'])) ? $data['ngaythemvao'] : null;
        $this->cannang = (!empty($data['cannang'])) ? $data['cannang'] : null;
        $this->gia = (!empty($data['gia'])) ? $data['gia'] : null;
    }

    public function getarray() {
        return array(
            'id' => $this->id,
            'tensanpham' => $this->tensanpham,
            'id_nhomsanpham' => $this->id_nhomsanpham,
            'gioitinh' =>$this->gioitinh,
            'xuatxu' => $this->xuatxu,
            'kichco' =>$this->kichco,
            'thongtinsanpham' =>$this->thongtinsanpham,
            'soluong' =>$this->soluong,
            'ngaythemvao' => $this->ngaythemvao,
            'cannang' => $this->cannang,
            'gia' => $this->gia
        );
    }

}
