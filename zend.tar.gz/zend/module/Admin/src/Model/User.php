<?php

namespace Admin\Model;

class User {

    public $id, $taikhoan, $matkhau, $ho,
            $ten, $diachi, $sodienthoai, $email, $ngaythangnamsinh, $quyentruycap,
    $congviec,$website,$anhdaidien;
    public function Copydata($data) {
        $this->id = (int)(!empty($data['id'])) ? (int)$data['id'] : null;
        $this->taikhoan = (!empty($data['taikhoan'])) ? $data['taikhoan'] : null;
        $this->matkhau = (!empty($data['matkhau'])) ? $data['matkhau'] : null;
        $this->ho = (!empty($data['ho'])) ? $data['ho'] : null;
        $this->ten = (!empty($data['ten'])) ? $data['ten'] : null;
        $this->diachi = (!empty($data['diachi'])) ? $data['diachi'] : null;
        $this->sodienthoai = (!empty($data['sodienthoai'])) ? $data['sodienthoai'] : null;
        $this->email = (!empty($data['email'])) ? $data['email'] : null;
        $this->ngaythangnamsinh = (!empty($data['ngaythangnamsinh'])) ? $data['ngaythangnamsinh'] : null;
        $this->quyentruycap = (int)(!empty($data['quyentruycap'])) ? (int)$data['quyentruycap'] : null;
        $this->congviec = (!empty($data['congviec'])) ? $data['congviec'] : null;
        $this->website = (!empty($data['website'])) ? $data['website'] : null;
        $this->anhdaidien = (!empty($data['anhdaidien'])) ? $data['anhdaidien'] : null;
    }

    public function getarray() {
        return array(
            'id' => $this->id,
            'taikhoan' => $this->taikhoan,
            'matkhau' => $this->matkhau,
            'ho' =>$this->ho,
            'ten' =>$this->ten,
            'diachi' =>$this->diachi,
            'email' =>$this->email,
            'ngaythangnamsinh' => $this->ngaythangnamsinh,
            'quyentruycap' =>$this->quyentruycap,
            'congviec' =>$this->congviec,
            'website' =>$this->website,
            'anhdaidien' =>$this->anhdaidien,
            'sodienthoai' =>$this->sodienthoai,
        );
    }

}
