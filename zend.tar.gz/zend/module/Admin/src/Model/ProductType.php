<?php

namespace Admin\Model;
use Admin\ModelInterface\LoaisanphamInterface;
class ProductType implements LoaisanphamInterface{

    public $id, $tenloaisanpham, $thongtinloaisanpham;

    public function Copydata($data) {
        $this->id_loaisanpham = (!empty($data['id_loaisanpham'])) ? $data['id_loaisanpham'] : null;
        $this->tenloaisanpham = (!empty($data['tenloaisanpham'])) ? $data['tenloaisanpham'] : null;
        $this->thongtinloaisanpham = (!empty($data['thongtinloaisanpham'])) ? $data['thongtinloaisanpham'] : null;
        
    }

    public function getarray() {
        return array(
            'id' => $this->id,
            'tenloaisanpham' => $this->tenloaisanpham,
            'thongtinloaisanpham' => $this->thongtinloaisanpham,
        );
    }

}
