<?php
/**
 * Created by PhpStorm.
 * User: quan
 * Date: 21/08/2017
 * Time: 21:50
 */

namespace Admin\Model;
use Zend\Db\TableGateway\TableGateway;

class DataTable
{
    private $table;
    public function __construct(TableGateway $table) {
        $this->table = $table;
    }
    //Lấy ra 1 dòng theo ID
    public function TakeID($id) {
        try
        {
            $result= $this->table->select(array('id' =>$id));

            foreach ($result as $row)
            {
                return $row;
            }
        } catch (Exception $ex) {
            echo "Lỗi";
            return false;
        }

    }
    //Lấy tòan bộ
    public function TakeAll() {
        return $this->table->select();
    }
    // Sửa hoặc thêm mới
    public function Save($table) {

        $data = $table->getarray();

        $id = (int) $table->id;

        if ($id == 0) {
            try{
                $this->table->insert($data);
            }
            catch (\Exception $e)
            {
                return $e->getMessage();
            }

        } else {
            $dt = $this->TakeID($id);
            if (isset($dt)) {
                $this->table->update($data, array('id' => $id));
            }
        }
    }
    //
    public function Delete($id) {
        $check = $this->table->select(array('id'=>$id));
        $data = $check->current();
        if(isset($data))
        {
            $this->table->delete(array('id' => $id));
        }
        else{
            return new \Exception('Lỗi');
        }

    }
    public function SQL($sql)
    {
        $adapter = $this->table->getAdapter();
        return $adapter->query($sql)->execute();
    }
    public function getTable()
    {
        return $this->table;
    }
}