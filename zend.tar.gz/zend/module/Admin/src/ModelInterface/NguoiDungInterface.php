<?php
namespace Admin\ModelInterface;
interface NguoiDungInterface
{
     public function getarray();

     public function setmatkhau($data);
     public function setho($data);
     public function settendem($data);
     public function setten($data);
     public function setdiachi($data);
     public function setsodienthoai($data);
     public function setemail($data);
     public function setngaythangnamsinh($data);
     public function setquyentruycap($data);
     
    
}
