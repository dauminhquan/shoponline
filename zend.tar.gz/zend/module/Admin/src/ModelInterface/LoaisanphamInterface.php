<?php
namespace Admin\ModelInterface;
interface LoaisanphamInterface
{
    public function Copydata($data);
    public function getarray();
}