<?php
namespace Admin\ModelInterface;
use Admin\Model\User;
interface TableInterface
{
    public function Laytoanbo();
    public function LaytheoId($id);
    public function Luu(User $data);//sua
    public function Xoa($id);
}