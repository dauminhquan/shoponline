<?php
namespace Admin\Factory;
use Admin\Controller\UserTableController;
use Admin\Model\DataTable;
use Zend\Db\Adapter\AdapterInterface;
use Zend\Db\TableGateway\TableGateway;
use Zend\ServiceManager\Factory\FactoryInterface;
use Admin\Model\BangNguoiDung;
use Interop\Container\ContainerInterface;
class UserTableControllerFactory implements FactoryInterface
{
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null) {

        $adapter =  $container->get(AdapterInterface::class);
        $table = new TableGateway('nguoidung',$adapter);
        return new UserTableController(new DataTable($table));
    }
}
