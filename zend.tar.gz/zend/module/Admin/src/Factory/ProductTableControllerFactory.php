<?php
/**
 * Created by PhpStorm.
 * User: quan
 * Date: 18/08/2017
 * Time: 20:09
 */

namespace Admin\Factory;


use Admin\Controller\ProductTableController;
use Admin\Model\BangSanpham;
use Admin\Model\BangNhomsanpham;
use Admin\Model\BangLoaisanpham;
use Admin\Model\DataTable;
use Admin\Model\ImageTable;
use Interop\Container\ContainerInterface;
use Interop\Container\Exception\ContainerException;
use Zend\Db\Adapter\AdapterInterface;
use Zend\Db\TableGateway\TableGateway;
use Zend\ServiceManager\Exception\ServiceNotCreatedException;
use Zend\ServiceManager\Exception\ServiceNotFoundException;
use Zend\ServiceManager\Factory\FactoryInterface;

class ProductTableControllerFactory implements FactoryInterface
{


    /**
     * Create an object
     *
     * @param  ContainerInterface $container
     * @param  string $requestedName
     * @param  null|array $options
     * @return object
     * @throws ServiceNotFoundException if unable to resolve the service.
     * @throws ServiceNotCreatedException if an exception is raised when
     *     creating a service.
     * @throws ContainerException if any other error occurs
     */
    public function __invoke(ContainerInterface $container, $requestedName, array $options = null)
    {
        $adapter = $container->get(AdapterInterface::class);
//        private $bangsanpham;
//        private $bangnhomsanpham;
//        private $bangloaisanpham;
//        private $imagetable;
//        private $banggioitinh;
//        private $bangkichco;
//        private $bangxuatxu;
//
        $bangsanpham = new TableGateway('sanpham',$adapter);
        $bangnhomsanpham = new TableGateway('nhomsanpham',$adapter);
        $bangloaisanpham = new TableGateway('loaisanpham',$adapter);
        $banggioitinh = new TableGateway('gioitinh',$adapter);
        $bangkichco = new TableGateway('kichco',$adapter);
        $bangxuatxu = new TableGateway('xuatxu',$adapter);
        $imagetable = new TableGateway('image',$adapter);

        return new ProductTableController(
          new DataTable($bangsanpham),
          new DataTable($bangnhomsanpham),
          new DataTable($bangloaisanpham),
          new DataTable($imagetable),
          new DataTable($banggioitinh),
          new DataTable($bangkichco),
          new DataTable($bangxuatxu)
        );

    }
}